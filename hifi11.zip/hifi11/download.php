<?php
require_once __DIR__ . '/config/config.php';

/**
 * download.php
 * =============
 * The "here's your bundle, click to download" landing page.
 * This page NEVER serves the file itself — it only decides whether to
 * show a valid download link (pointing at download-file.php, which
 * re-checks everything independently) or a 403 / login redirect.
 *
 * Access rules:
 *  - Not logged in                       -> redirect to login.php
 *  - Logged in, no ?token= given          -> look up the customer's own
 *                                            most recent PAID order and
 *                                            mint a fresh token for it
 *  - Logged in, ?token= given             -> must pass authorizeDownload()
 *                                            (belongs to THIS customer,
 *                                            not expired/revoked, order
 *                                            paid, limit not reached)
 *    otherwise -> 403 Forbidden (never a silent redirect to success)
 */

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$customerId = (int) $_SESSION['customer_id'];
$token = trim($_GET['token'] ?? '');

function renderForbidden(string $message): void
{
    http_response_code(403);
    $pageTitle = 'Access Denied — ' . SITE_NAME;
    require __DIR__ . '/includes/header.php';
    ?>
    <section class="premium-bg page-hero text-center" style="min-height:60vh; display:flex; align-items:center;">
      <div class="container">
        <i class="bi bi-shield-exclamation text-danger" style="font-size:3rem;"></i>
        <h2 class="fw-bold mt-3">403 — Access Denied</h2>
        <p class="text-secondary"><?= e($message) ?></p>
        <a href="my-downloads.php" class="btn btn-primary rounded-pill px-4 py-3 gradient-btn mt-2">Go to My Downloads</a>
      </div>
    </section>
    <?php
    require __DIR__ . '/includes/footer.php';
    exit;
}

if ($token !== '') {
    // A specific token was supplied (e.g. straight after checkout) —
    // validate it strictly. Any failure here is a 403, never a redirect
    // to a success/download state.
    $auth = authorizeDownload($token, $customerId);
    if (!$auth['ok']) {
        renderForbidden('This download link is invalid, expired, or does not belong to your account.');
    }
    $order = $auth['order'];
    $version = $auth['version'];
    $downloadToken = $token;
} else {
    // No token in the URL — fall back to the customer's own purchase
    // history (never someone else's) and mint a fresh token for it.
    $bundles = getPurchasedBundles($customerId);
    if (empty($bundles)) {
        renderForbidden('No paid purchase was found on your account for this bundle.');
    }

    $db = getDB();
    $orderStmt = $db->prepare('SELECT * FROM orders WHERE id = ? AND customer_id = ? AND status = "paid" LIMIT 1');
    $orderStmt->execute([(int) $bundles[0]['order_id'], $customerId]);
    $order = $orderStmt->fetch();

    if (!$order) {
        renderForbidden('No paid purchase was found on your account for this bundle.');
    }

    $verStmt = $db->prepare('SELECT * FROM bundle_versions WHERE is_current = 1 ORDER BY released_at DESC LIMIT 1');
    $verStmt->execute();
    $version = $verStmt->fetch() ?: [
        'version'       => PRODUCT_VERSION,
        'file_size_mb'  => 4200,
        'released_at'   => date('Y-m-d'),
        'release_notes' => 'Initial release.',
    ];

    $downloadToken = issueDownloadToken($customerId, (int) $order['id'], DOWNLOAD_MAX_COUNT);
}

$customer = currentCustomer();

$pageTitle = 'Download Your Bundle — ' . SITE_NAME;
require __DIR__ . '/includes/header.php';
?>

<section class="premium-bg page-hero" style="position:relative;">
  <div class="glow-sphere" style="width:300px;height:300px;background:#06B6D4;top:-10%;right:-5%;"></div>
  <div class="container position-relative" style="z-index:1;">
    <div class="row justify-content-center">
      <div class="col-lg-7" data-aos="fade-up">
        <div class="app-card text-center">
          <i class="bi bi-box-seam-fill text-primary" style="font-size:3rem;"></i>
          <h2 class="fw-bold mt-3"><?= e(PRODUCT_NAME) ?></h2>
          <p class="text-secondary">Your secure download is ready, <?= e(explode(' ', $customer['full_name'] ?? 'there')[0]) ?>.</p>

          <div class="row g-3 my-4">
            <div class="col-4"><div class="stat-tile"><div class="stat-value"><?= e($version['version']) ?></div><div class="stat-label">Version</div></div></div>
            <div class="col-4"><div class="stat-tile"><div class="stat-value"><?= e(formatDate($version['released_at'])) ?></div><div class="stat-label">Released</div></div></div>
            <div class="col-4"><div class="stat-tile"><div class="stat-value"><?= number_format(($version['file_size_mb'] ?? 4200)) ?> MB</div><div class="stat-label">File Size</div></div></div>
          </div>

          <!-- This link goes through download-file.php, which independently
               re-verifies session + token + payment status before streaming
               a single byte. The real file path/location is never exposed. -->
          <a href="download-file.php?token=<?= urlencode($downloadToken) ?>" class="btn btn-primary btn-lg rounded-pill px-5 py-3 gradient-btn">
            <i class="bi bi-download me-2"></i> Download Now
          </a>

          <p class="text-muted small mt-3">Order placed on <?= formatDate($order['created_at']) ?> • Purchased under <?= e($customer['email'] ?? '') ?></p>

          <div class="app-card-soft text-start mt-4">
            <h6 class="fw-bold mb-2"><i class="bi bi-info-circle text-primary me-1"></i> Instructions</h6>
            <ul class="small text-secondary mb-0">
              <li>Extract the ZIP file using WinRAR / 7-Zip / built-in extractor.</li>
              <li>Videos and PDFs are organized by module inside the folder.</li>
              <li>This download link is valid for 24 hours and can be reused up to <?= (int) DOWNLOAD_MAX_COUNT ?> times.</li>
              <li>Need a fresh link later? Just visit <a href="my-downloads.php">My Downloads</a> from your dashboard.</li>
            </ul>
          </div>

          <?php if (!empty($version['release_notes'])): ?>
            <p class="text-muted small mt-3 mb-0"><i class="bi bi-megaphone me-1"></i> <?= e($version['release_notes']) ?></p>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
