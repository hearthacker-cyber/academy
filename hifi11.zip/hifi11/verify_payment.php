<?php
/**
 * verify_payment.php
 * ===================
 * Called via fetch() from process-payment.php's Razorpay `handler`
 * callback — i.e. only after Razorpay itself has told the browser the
 * payment succeeded. This endpoint independently re-verifies that with
 * the server-side signature check before touching the database.
 *
 * Nothing here should ever be trusted blindly: a malicious client could
 * call this endpoint directly with made-up values, which is exactly why
 * verifyPayment() (HMAC signature check) is mandatory, not optional.
 */

require_once __DIR__ . '/config/config.php';

header('Content-Type: application/json');

function respond(int $httpCode, array $body): void
{
    http_response_code($httpCode);
    echo json_encode($body);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(405, ['success' => false, 'message' => 'Method not allowed.']);
}

$raw = file_get_contents('php://input');
$input = json_decode((string) $raw, true);

if (!is_array($input)) {
    respond(400, ['success' => false, 'message' => 'Invalid request.']);
}

// CSRF check (token was embedded in process-payment.php and sent back here)
$csrfToken = (string) ($input['csrf_token'] ?? '');
if (empty($_SESSION[CSRF_TOKEN_NAME]) || !hash_equals($_SESSION[CSRF_TOKEN_NAME], $csrfToken)) {
    respond(419, ['success' => false, 'message' => 'Your session has expired. Please refresh and try again.']);
}

// There must be a pending checkout in session (created by checkout.php)
if (empty($_SESSION['checkout']['razorpay_order_id'])) {
    respond(400, ['success' => false, 'message' => 'No pending checkout found. Please start again.']);
}

$checkout = $_SESSION['checkout'];

$razorpayPaymentId = trim((string) ($input['razorpay_payment_id'] ?? ''));
$razorpayOrderId   = trim((string) ($input['razorpay_order_id'] ?? ''));
$razorpaySignature = trim((string) ($input['razorpay_signature'] ?? ''));

if ($razorpayPaymentId === '' || $razorpayOrderId === '' || $razorpaySignature === '') {
    respond(400, ['success' => false, 'message' => 'Missing payment details from the gateway response.']);
}

// The order id returned by Razorpay MUST match the one we created for
// this session — prevents replaying a signature from a different order.
if (!hash_equals($checkout['razorpay_order_id'], $razorpayOrderId)) {
    error_log('verify_payment.php: order id mismatch. session=' . $checkout['razorpay_order_id'] . ' received=' . $razorpayOrderId);
    respond(400, ['success' => false, 'message' => 'Order mismatch. Please start checkout again.']);
}

// ---- The critical step: verify the signature server-side ----
$verified = verifyPayment($razorpayOrderId, $razorpayPaymentId, $razorpaySignature);

if (!$verified) {
    error_log('verify_payment.php: signature verification FAILED for order ' . $razorpayOrderId);
    respond(400, [
        'success' => false,
        'message' => 'Payment verification failed. If any amount was deducted, it will be automatically refunded. Please contact support if this persists.',
    ]);
}

try {
    $result = paymentSuccess(
        [
            'name'   => $checkout['full_name'],
            'email'  => $checkout['email'],
            'mobile' => $checkout['mobile'],
        ],
        [
            'razorpay_order_id'   => $razorpayOrderId,
            'razorpay_payment_id' => $razorpayPaymentId,
            'amount'              => PRODUCT_PRICE,
        ]
    );
} catch (Throwable $e) {
    error_log('verify_payment.php: paymentSuccess() failed: ' . $e->getMessage());
    respond(500, [
        'success' => false,
        'message' => 'Your payment was verified but we could not save your order. Please contact support with your payment ID: ' . $razorpayPaymentId,
    ]);
}

$downloadToken = issueDownloadToken($result['customer_id'], $result['order_id'], DOWNLOAD_MAX_COUNT);

// Hand the confirmed result to payment-success.php via session (never via
// a trust-the-client GET parameter).
$_SESSION['payment_result'] = [
    'order_id'       => $result['order_id'],
    'customer_id'    => $result['customer_id'],
    'full_name'      => $checkout['full_name'],
    'email'          => $checkout['email'],
    'payment_id'     => $razorpayPaymentId,
    'download_token' => $downloadToken,
];

unset($_SESSION['checkout']);

respond(200, ['success' => true, 'redirect' => 'payment-success.php']);
