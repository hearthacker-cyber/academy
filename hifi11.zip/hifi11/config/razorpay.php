<?php
/**
 * HIFI11 Academy - Razorpay Integration
 * ======================================================
 * Real server-side integration using Razorpay's REST API directly via
 * cURL (no Composer SDK required). If you later install
 * `composer require razorpay/razorpay`, you can swap the internals of
 * createOrder()/verifyPayment() for SDK calls without touching any
 * other file — the function signatures stay the same.
 *
 * Docs: https://razorpay.com/docs/api/orders/
 *       https://razorpay.com/docs/payments/server-integration/php/build-integration/#3-verify-payment-signature
 */

// ---- API Keys -----------------------------------------------------
// Prefer environment variables in production (e.g. set via your host's
// control panel or a .env loader). Falls back to the hardcoded values
// only if the environment variable isn't set.
define('RAZORPAY_KEY_ID', getenv('RAZORPAY_KEY_ID') ?: 'rzp_test_TDVT06fAIdDelR');
define('RAZORPAY_KEY_SECRET', getenv('RAZORPAY_KEY_SECRET') ?: 'XmxdTO6rhf5nK1qTw7444JiX');

class RazorpayException extends RuntimeException {}

/**
 * Low-level helper: signed cURL request to the Razorpay REST API.
 *
 * @throws RazorpayException on network failure or a non-2xx response
 */
function razorpayApiRequest(string $method, string $path, array $payload = []): array
{
    $ch = curl_init('https://api.razorpay.com/v1' . $path);

    $options = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => strtoupper($method),
        CURLOPT_USERPWD        => RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_CONNECTTIMEOUT => 10,
    ];

    if (!empty($payload)) {
        $options[CURLOPT_POSTFIELDS] = json_encode($payload);
    }

    curl_setopt_array($ch, $options);
    $response = curl_exec($ch);
    $curlErrno = curl_errno($ch);
    $curlError = curl_error($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curlErrno !== 0) {
        error_log('Razorpay API cURL error: ' . $curlError);
        throw new RazorpayException('Could not reach the payment gateway. Please try again.');
    }

    $decoded = json_decode((string) $response, true);

    if ($httpCode < 200 || $httpCode >= 300) {
        $message = $decoded['error']['description'] ?? 'Payment gateway returned an error.';
        error_log('Razorpay API error (' . $httpCode . '): ' . (string) $response);
        throw new RazorpayException($message);
    }

    if (!is_array($decoded)) {
        error_log('Razorpay API returned invalid JSON: ' . (string) $response);
        throw new RazorpayException('Unexpected response from the payment gateway.');
    }

    return $decoded;
}

/**
 * createOrder()
 * Creates a Razorpay order for the given amount (in paise) and returns
 * an order object that the checkout page uses to open Razorpay Checkout.
 *
 * @param int $amountInPaise e.g. 199 * 100
 * @param string $receiptId  your internal order/receipt reference
 * @return array{id:string, amount:int, currency:string}
 * @throws RazorpayException if the order could not be created
 */
function createOrder(int $amountInPaise, string $receiptId): array
{
    $order = razorpayApiRequest('POST', '/orders', [
        'receipt'         => $receiptId,
        'amount'          => $amountInPaise,
        'currency'        => PRODUCT_CURRENCY,
        'payment_capture' => 1, // auto-capture on successful authorization
    ]);

    if (empty($order['id'])) {
        throw new RazorpayException('Payment gateway did not return an order id.');
    }

    return $order;
}

/**
 * verifyPayment()
 * Verifies the Razorpay payment signature returned by Razorpay Checkout
 * after a successful payment on the front end. This is the step that
 * proves the payment response actually came from Razorpay and wasn't
 * forged by the browser.
 *
 * Formula (per Razorpay docs): HMAC-SHA256(order_id + "|" + payment_id, key_secret)
 *
 * @return bool true if the signature is valid
 */
function verifyPayment(string $razorpayOrderId, string $razorpayPaymentId, string $razorpaySignature): bool
{
    if ($razorpayOrderId === '' || $razorpayPaymentId === '' || $razorpaySignature === '') {
        return false;
    }

    $expectedSignature = hash_hmac(
        'sha256',
        $razorpayOrderId . '|' . $razorpayPaymentId,
        RAZORPAY_KEY_SECRET
    );

    return hash_equals($expectedSignature, $razorpaySignature);
}

/**
 * paymentSuccess()
 * Called once a payment has been verified. Responsible for:
 *  - creating/finding the customer record
 *  - creating the order record (status = paid)
 *
 * @param array $customer  ['name'=>, 'email'=>, 'mobile'=>]
 * @param array $paymentData ['razorpay_order_id'=>, 'razorpay_payment_id'=>, 'amount'=>]
 * @return array{order_id:int, customer_id:int} internal DB ids
 */
function paymentSuccess(array $customer, array $paymentData): array
{
    $db = getDB();
    $db->beginTransaction();

    try {
        // Find or create the customer
        $stmt = $db->prepare('SELECT id FROM customers WHERE email = ? LIMIT 1');
        $stmt->execute([$customer['email']]);
        $existing = $stmt->fetch();

        if ($existing) {
            $customerId = (int) $existing['id'];
            $upd = $db->prepare('UPDATE customers SET full_name = ?, mobile = ? WHERE id = ?');
            $upd->execute([$customer['name'], $customer['mobile'], $customerId]);
        } else {
            $ins = $db->prepare('INSERT INTO customers (full_name, email, mobile, created_at) VALUES (?, ?, ?, NOW())');
            $ins->execute([$customer['name'], $customer['email'], $customer['mobile']]);
            $customerId = (int) $db->lastInsertId();
        }

        // Avoid double-inserting if this Razorpay payment was already recorded
        // (e.g. the browser retried the handler callback).
        $dupe = $db->prepare('SELECT id FROM orders WHERE razorpay_payment_id = ? LIMIT 1');
        $dupe->execute([$paymentData['razorpay_payment_id']]);
        $dupeRow = $dupe->fetch();

        if ($dupeRow) {
            $orderId = (int) $dupeRow['id'];
        } else {
            $orderStmt = $db->prepare(
                'INSERT INTO orders (customer_id, razorpay_order_id, razorpay_payment_id, amount, currency, status, created_at)
                 VALUES (?, ?, ?, ?, ?, "paid", NOW())'
            );
            $orderStmt->execute([
                $customerId,
                $paymentData['razorpay_order_id'],
                $paymentData['razorpay_payment_id'],
                $paymentData['amount'],
                PRODUCT_CURRENCY,
            ]);
            $orderId = (int) $db->lastInsertId();
        }

        $db->commit();
    } catch (Throwable $e) {
        $db->rollBack();
        error_log('paymentSuccess() DB error: ' . $e->getMessage());
        throw $e;
    }

    // ---------------------------------------------------------------
    // Replace this section with your real email service (SMTP/API).
    // e.g. PHPMailer, SendGrid, Postmark, etc.
    // mail($customer['email'], 'Your HIFI11 Academy Purchase', '...');
    // ---------------------------------------------------------------

    // Auto-login the customer immediately after purchase
    $_SESSION['customer_id'] = $customerId;
    $_SESSION['customer_email'] = $customer['email'];

    return ['order_id' => $orderId, 'customer_id' => $customerId];
}

/**
 * getPurchasedBundles()
 * Returns all bundles/orders purchased by the given customer, joined
 * with the latest available version info.
 *
 * @param int $customerId
 * @return array
 */
function getPurchasedBundles(int $customerId): array
{
    $db = getDB();
    $stmt = $db->prepare(
        'SELECT o.id AS order_id, o.razorpay_payment_id, o.amount, o.created_at AS purchased_at,
                bv.version, bv.release_notes, bv.released_at
         FROM orders o
         LEFT JOIN bundle_versions bv ON bv.is_current = 1
         WHERE o.customer_id = ? AND o.status = "paid"
         ORDER BY o.created_at DESC'
    );
    $stmt->execute([$customerId]);
    return $stmt->fetchAll();
}
