<?php
require_once __DIR__ . '/config/config.php';

// This page must only be reached right after checkout.php successfully
// created a Razorpay order. If that session data is missing, there's
// nothing to pay for — send the customer back to the checkout form.
if (empty($_SESSION['checkout']['razorpay_order_id'])) {
    header('Location: checkout.php');
    exit;
}

$checkout = $_SESSION['checkout'];

$pageTitle = 'Processing Payment — ' . SITE_NAME;
require __DIR__ . '/includes/header.php';
?>

<section class="premium-bg page-hero" style="position:relative; min-height:70vh; display:flex; align-items:center;">
  <div class="glow-sphere" style="width:300px;height:300px;background:#2563EB;top:-10%;left:-5%;"></div>
  <div class="grid-overlay"></div>
  <div class="container position-relative text-center" style="z-index:1;">
    <div class="row justify-content-center">
      <div class="col-lg-6">
        <div class="app-card" id="payment-status-card">
          <div id="payment-loading">
            <div class="spinner-border text-primary mb-3" role="status" style="width:3rem;height:3rem;">
              <span class="visually-hidden">Loading...</span>
            </div>
            <h5 class="fw-bold mb-2">Opening Secure Razorpay Checkout…</h5>
            <p class="text-secondary small mb-0">Please do not close or refresh this page.</p>
            <button type="button" id="open-checkout-btn" class="btn btn-primary rounded-pill px-4 py-2 gradient-btn mt-4">
              <i class="bi bi-shield-lock-fill me-2"></i> Open Payment Window
            </button>
          </div>

          <div id="payment-error" class="d-none">
            <i class="bi bi-exclamation-triangle-fill text-danger" style="font-size:2.5rem;"></i>
            <h5 class="fw-bold mt-3 mb-2">Something went wrong</h5>
            <p class="text-secondary small" id="payment-error-message">We couldn't verify your payment.</p>
            <a href="checkout.php" class="btn btn-outline-primary-soft rounded-pill px-4 py-2 mt-2">Back to Checkout</a>
          </div>
        </div>
        <p class="text-muted small mt-3"><i class="bi bi-lock-fill me-1"></i> Payments are processed securely by Razorpay. HIFI11 Academy never sees or stores your card details.</p>
      </div>
    </div>
  </div>
</section>

<!-- Razorpay Checkout.js -->
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
(function () {
  var CSRF_TOKEN = <?= json_encode(csrfToken()) ?>;
  var openBtn = document.getElementById('open-checkout-btn');
  var errorBox = document.getElementById('payment-error');
  var errorMsg = document.getElementById('payment-error-message');
  var loadingBox = document.getElementById('payment-loading');

  function showError(message) {
    loadingBox.classList.add('d-none');
    errorBox.classList.remove('d-none');
    errorMsg.textContent = message || 'We could not verify your payment. If any amount was deducted, it will be auto-refunded within a few business days.';
  }

  function verifyOnServer(response) {
    fetch('verify_payment.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        razorpay_payment_id: response.razorpay_payment_id,
        razorpay_order_id: response.razorpay_order_id,
        razorpay_signature: response.razorpay_signature,
        csrf_token: CSRF_TOKEN
      })
    })
      .then(function (r) { return r.json().then(function (data) { return { ok: r.ok, data: data }; }); })
      .then(function (result) {
        if (result.ok && result.data && result.data.success) {
          window.location.href = result.data.redirect || 'payment-success.php';
        } else {
          showError(result.data && result.data.message);
        }
      })
      .catch(function () {
        showError('Network error while verifying your payment. Please contact support with your payment ID: ' + response.razorpay_payment_id);
      });
  }

  var options = {
    key: <?= json_encode(RAZORPAY_KEY_ID) ?>,
    amount: <?= (int) $checkout['amount_paise'] ?>,
    currency: <?= json_encode(PRODUCT_CURRENCY) ?>,
    name: <?= json_encode(SITE_NAME) ?>,
    description: <?= json_encode(PRODUCT_NAME) ?>,
    order_id: <?= json_encode($checkout['razorpay_order_id']) ?>,
    prefill: {
      name: <?= json_encode($checkout['full_name']) ?>,
      email: <?= json_encode($checkout['email']) ?>,
      contact: <?= json_encode($checkout['mobile']) ?>
    },
    theme: { color: '#2563EB' },
    handler: function (response) {
      // Runs only when Razorpay itself confirms the payment succeeded.
      loadingBox.querySelector('h5').textContent = 'Verifying your payment…';
      loadingBox.querySelector('.spinner-border').style.display = '';
      verifyOnServer(response);
    },
    modal: {
      // Fires when the customer closes the popup without paying.
      ondismiss: function () {
        window.location.href = 'checkout.php?cancelled=1';
      },
      escape: true,
      confirm_close: true
    },
    retry: { enabled: true }
  };

  var rzp = new Razorpay(options);

  // Fires when Razorpay itself reports the payment attempt failed
  // (declined card, insufficient funds, etc). Do NOT proceed to success.
  rzp.on('payment.failed', function (resp) {
    window.location.href = 'checkout.php?failed=1';
  });

  function openCheckout() {
    errorBox.classList.add('d-none');
    loadingBox.classList.remove('d-none');
    rzp.open();
  }

  openBtn.addEventListener('click', openCheckout);

  // Auto-open as soon as the page loads so the customer doesn't have to
  // click twice. The manual button above remains as a fallback in case
  // the browser blocks the automatic open.
  window.addEventListener('load', function () {
    setTimeout(openCheckout, 300);
  });
})();
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
