<!DOCTYPE html>
<html lang="ta">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.5" />
  <title>HIFI11 ACADEMY – Premium Ethical Hacking Bundle Pack ₹199</title>
  <meta name="description" content="Premium Digital Bundle Pack: 2 Complete Ethical Hacking Courses. Instant Download. One-Time Purchase ₹199. Worth ₹15,000+." />
  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
  <!-- Bootstrap 5 + Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
  <!-- AOS -->
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
  <style>
    /* ---------- BASE ---------- */
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Poppins', sans-serif;
      background: #FFFFFF;
      color: #0F172A;
      overflow-x: hidden;
    }
    h1,h2,h3,h4,h5,.display-1,.display-2,.display-3,.display-4,.display-5,.display-6 {
      font-family: 'Space Grotesk', sans-serif;
      font-weight: 700;
    }
    .bg-soft-primary { background: #F8FAFC; }
    .text-primary { color: #2563EB !important; }
    .text-secondary { color: #64748B !important; }

    /* ---------- PREMIUM BACKGROUND ---------- */
    .premium-bg {
      position: relative;
      background: #FFFFFF;
      overflow: hidden;
    }
    .premium-bg::before {
      content: '';
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at 20% 30%, rgba(37,99,235,0.04) 0%, transparent 50%),
                  radial-gradient(circle at 80% 70%, rgba(6,182,212,0.05) 0%, transparent 50%);
      pointer-events: none;
      z-index: 0;
    }
    .grid-overlay {
      position: absolute;
      inset: 0;
      background-image: 
        linear-gradient(rgba(37,99,235,0.02) 1px, transparent 1px),
        linear-gradient(90deg, rgba(37,99,235,0.02) 1px, transparent 1px);
      background-size: 60px 60px;
      pointer-events: none;
      z-index: 0;
    }
    .glow-sphere {
      position: absolute;
      border-radius: 50%;
      filter: blur(80px);
      opacity: 0.25;
      pointer-events: none;
      z-index: 0;
    }

    /* ---------- ANNOUNCEMENT BAR ---------- */
    .announcement-bar {
      background: linear-gradient(135deg, #1E40AF, #2563EB);
      color: #fff;
      padding: 10px 0;
      font-size: 0.85rem;
      font-weight: 500;
      text-align: center;
      z-index: 1040;
      position: sticky;
      top: 0;
      overflow: hidden;
    }
    .announcement-bar .scroll-text {
      display: inline-block;
      animation: scrollAnnounce 18s linear infinite;
      white-space: nowrap;
    }
    @keyframes scrollAnnounce {
      0% { transform: translateX(100%); }
      100% { transform: translateX(-100%); }
    }

    /* ---------- NAVBAR ---------- */
    .navbar {
      backdrop-filter: blur(16px);
      background: rgba(255,255,255,0.80);
      border-bottom: 1px solid rgba(229,231,235,0.5);
      z-index: 1030;
    }
    .navbar-brand {
      font-family: 'Space Grotesk', sans-serif;
      font-weight: 700;
      font-size: 1.4rem;
      letter-spacing: -0.5px;
    }
    .navbar-brand i { color: #2563EB; margin-right: 6px; }

    /* ---------- BUTTONS ---------- */
    .gradient-btn {
      background: linear-gradient(135deg, #2563EB 0%, #06B6D4 100%);
      border: none;
      color: #fff;
      transition: all 0.3s ease;
      box-shadow: 0 8px 28px rgba(37,99,235,0.25);
      position: relative;
      overflow: hidden;
    }
    .gradient-btn:hover {
      transform: translateY(-3px) scale(1.02);
      box-shadow: 0 14px 36px rgba(37,99,235,0.35);
      color: #fff;
    }

    /* ---------- FLOATING ---------- */
    .float-slow { animation: floatY 7s ease-in-out infinite; }
    .float-med { animation: floatY 5s ease-in-out infinite; }
    .float-fast { animation: floatY 3.5s ease-in-out infinite; }
    @keyframes floatY {
      0% { transform: translateY(0px) rotate(0deg); }
      50% { transform: translateY(-16px) rotate(1deg); }
      100% { transform: translateY(0px) rotate(0deg); }
    }

    /* ---------- HERO IMAGE ---------- */
    .hero-image-container {
      position: relative;
      border-radius: 32px;
      overflow: hidden;
      box-shadow: 0 30px 60px -20px rgba(0,0,0,0.15);
      transition: all 0.4s;
    }
    .hero-image-container img {
      width: 100%;
      height: auto;
      display: block;
      transition: transform 0.6s;
    }
    .hero-image-container:hover img { transform: scale(1.02); }

    .cyber-float {
      position: absolute;
      background: rgba(255,255,255,0.7);
      backdrop-filter: blur(12px);
      border-radius: 20px;
      padding: 10px 16px;
      border: 1px solid rgba(255,255,255,0.3);
      box-shadow: 0 12px 32px -8px rgba(0,0,0,0.06);
      font-weight: 500;
      font-size: 0.8rem;
      display: flex;
      align-items: center;
      gap: 8px;
      pointer-events: none;
    }

    /* ---------- PRICING CARD ---------- */
    .pricing-card {
      background: #F8FAFC;
      border-radius: 32px;
      padding: 1.5rem 2rem;
      border: 1px solid #E5E7EB;
      max-width: 400px;
    }
    .pricing-card .strike { text-decoration: line-through; color: #94A3B8; font-size: 1.2rem; }
    .pricing-card .price { font-size: 3.2rem; font-weight: 800; color: #2563EB; }
    .badge-save {
      background: #10B981;
      color: #fff;
      border-radius: 40px;
      padding: 4px 16px;
      font-weight: 600;
      font-size: 0.85rem;
    }

    /* ---------- VALUE TABLE ---------- */
    .value-table {
      border-radius: 28px;
      overflow: hidden;
      border: 1px solid #E5E7EB;
    }
    .value-table .row-item {
      padding: 1rem 1.5rem;
      border-bottom: 1px solid #E5E7EB;
      display: flex;
      justify-content: space-between;
      background: #fff;
    }
    .value-table .row-item:last-child { border-bottom: none; }
    .value-table .row-item.total {
      background: #F0FDF4;
      font-weight: 700;
      border-top: 2px solid #10B981;
    }
    .value-table .row-item.highlight {
      background: #EFF6FF;
      border-left: 4px solid #2563EB;
    }

    /* ---------- GLASS CARD ---------- */
    .glass-card {
      background: rgba(255,255,255,0.6);
      backdrop-filter: blur(12px);
      border: 1px solid rgba(255,255,255,0.4);
      border-radius: 28px;
      transition: all 0.3s;
    }
    .glass-card:hover {
      background: rgba(255,255,255,0.85);
      transform: translateY(-6px);
      box-shadow: 0 24px 48px -12px rgba(37,99,235,0.06);
    }

    /* ---------- APPLE CTA ---------- */
    .cta-apple {
      background: linear-gradient(135deg, #1E40AF, #2563EB, #06B6D4);
      border-radius: 64px;
      padding: 4rem 3rem;
      position: relative;
      overflow: hidden;
      box-shadow: 0 40px 80px -20px rgba(37,99,235,0.25);
    }
    .cta-apple .glow-ring {
      position: absolute;
      width: 600px;
      height: 600px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 70%);
      top: -200px;
      right: -200px;
      pointer-events: none;
    }
    .cta-apple .btn-apple {
      background: #fff;
      color: #2563EB;
      border-radius: 60px;
      padding: 18px 56px;
      font-weight: 700;
      font-size: 1.2rem;
      transition: all 0.3s;
      box-shadow: 0 12px 32px rgba(0,0,0,0.08);
      letter-spacing: 0.5px;
    }
    .cta-apple .btn-apple:hover {
      transform: scale(1.04);
      box-shadow: 0 20px 40px rgba(0,0,0,0.12);
      color: #1E40AF;
    }

    /* ---------- WAVE ---------- */
    .wave-divider {
      width: 100%;
      display: block;
      fill: #F8FAFC;
      margin: -2px 0;
    }
    .wave-divider-dark { fill: #FFFFFF; }

    /* ---------- FLOATING SOCIAL BUTTONS ---------- */
    .social-float {
      position: fixed;
      right: 24px;
      z-index: 1050;
      width: 52px;
      height: 52px;
      border-radius: 60px;
      background: rgba(255,255,255,0.9);
      backdrop-filter: blur(10px);
      box-shadow: 0 8px 24px rgba(0,0,0,0.08);
      border: 1px solid rgba(229,231,235,0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.4rem;
      color: #0F172A;
      transition: all 0.3s cubic-bezier(0.23, 1, 0.32, 1);
      text-decoration: none;
      cursor: pointer;
    }
    .social-float:hover { 
      transform: scale(1.12) translateY(-3px); 
      background: #fff;
      box-shadow: 0 12px 32px rgba(0,0,0,0.12);
    }
    .social-float.whatsapp { bottom: 210px; color: #25D366; border-color: #25D36640; }
    .social-float.instagram { bottom: 150px; color: #E4405F; border-color: #E4405F40; }
    .social-float.telegram { bottom: 90px; color: #0088CC; border-color: #0088CC40; }
    .social-float.top { bottom: 28px; color: #2563EB; border-color: #2563EB30; }

    .social-float .tooltip-text {
      position: absolute;
      right: 62px;
      background: rgba(15,23,42,0.85);
      backdrop-filter: blur(8px);
      color: #fff;
      padding: 4px 14px;
      border-radius: 40px;
      font-size: 0.7rem;
      font-weight: 500;
      white-space: nowrap;
      opacity: 0;
      transform: translateX(10px);
      transition: all 0.3s ease;
      pointer-events: none;
    }
    .social-float:hover .tooltip-text {
      opacity: 1;
      transform: translateX(0);
    }

    /* ---------- COUNTER ---------- */
    .counter { font-size: 2.8rem; }

    /* ---------- FEATURE ICON ---------- */
    .icon-feature {
      background: white;
      border-radius: 24px;
      padding: 1.5rem 1rem;
      border: 1px solid #E5E7EB;
      transition: all 0.25s;
      text-align: center;
      height: 100%;
    }
    .icon-feature:hover {
      transform: translateY(-8px);
      box-shadow: 0 20px 40px -12px rgba(37,99,235,0.10);
      border-color: #2563EB30;
    }
    .icon-feature i { font-size: 2rem; color: #2563EB; }

    /* ---------- BONUS CARD ---------- */
    .bonus-card {
      background: #F8FAFC;
      border-radius: 20px;
      padding: 1.5rem;
      border: 1px solid #E5E7EB;
      text-align: center;
      transition: all 0.25s;
    }
    .bonus-card:hover {
      background: #fff;
      border-color: #2563EB;
      box-shadow: 0 12px 28px rgba(37,99,235,0.06);
      transform: translateY(-4px);
    }
    .bonus-card i { font-size: 2rem; color: #2563EB; }

    /* ---------- TRUST BADGE ---------- */
    .trust-badge {
      background: #F8FAFC;
      border-radius: 40px;
      padding: 6px 18px;
      border: 1px solid #E5E7EB;
      font-size: 0.85rem;
      font-weight: 500;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }
    .trust-badge i { color: #10B981; }

    /* ---------- STICKY MOBILE BUY ---------- */
    .sticky-mobile-buy {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      background: rgba(255,255,255,0.92);
      backdrop-filter: blur(12px);
      padding: 12px 16px;
      border-top: 1px solid #E5E7EB;
      z-index: 1040;
      display: none;
    }
    @media (max-width: 768px) {
      .sticky-mobile-buy { display: flex; align-items: center; gap: 12px; }
      .sticky-mobile-buy .price { font-size: 1.4rem; font-weight: 700; color: #2563EB; }
      .sticky-mobile-buy .btn { flex: 1; border-radius: 40px; padding: 12px; font-weight: 600; }
      .counter { font-size: 2rem; }
      .cta-apple { padding: 2.5rem 1.5rem; border-radius: 32px; }
      .pricing-card .price { font-size: 2.4rem; }
      .social-float { width: 44px; height: 44px; font-size: 1.1rem; right: 16px; }
      .social-float.whatsapp { bottom: 180px; }
      .social-float.instagram { bottom: 128px; }
      .social-float.telegram { bottom: 76px; }
      .social-float.top { bottom: 20px; }
      .social-float .tooltip-text { display: none; }
    }

    /* ---------- LIVE DOWNLOAD NOTIFICATIONS ---------- */
    .download-notification {
      position: fixed;
      left: 20px;
      bottom: 90px;
      z-index: 1060;
      background: rgba(255,255,255,0.92);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(229,231,235,0.6);
      border-radius: 16px;
      padding: 12px 18px;
      min-width: 220px;
      max-width: 300px;
      box-shadow: 0 20px 48px -12px rgba(0,0,0,0.10);
      opacity: 0;
      transform: translateX(-30px) scale(0.95);
      transition: opacity 0.5s ease, transform 0.5s cubic-bezier(0.23, 1, 0.32, 1);
      pointer-events: none;
    }
    .download-notification.show {
      opacity: 1;
      transform: translateX(0) scale(1);
      pointer-events: auto;
    }
    .download-notification.hide {
      opacity: 0;
      transform: translateX(-30px) scale(0.95);
    }
    .download-notification .avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: linear-gradient(135deg, #2563EB20, #06B6D420);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 0.8rem;
      color: #2563EB;
      flex-shrink: 0;
      border: 2px solid #fff;
      box-shadow: 0 0 0 2px #10B981;
    }
    .download-notification .online-dot {
      width: 8px;
      height: 8px;
      background: #10B981;
      border-radius: 50%;
      display: inline-block;
      margin-right: 4px;
      animation: pulse 1.5s infinite;
    }
    .download-notification .notif-text {
      font-size: 0.8rem;
      line-height: 1.3;
    }
    .download-notification .notif-text strong { color: #0F172A; }
    .download-notification .notif-text .action { color: #2563EB; font-weight: 500; }
    .download-notification .time { font-size: 0.65rem; color: #94A3B8; }

    @media (max-width: 768px) {
      .download-notification { left: 12px; right: 12px; bottom: 80px; max-width: none; min-width: auto; }
    }

    /* ---------- CONTACT SECTION ---------- */
    .contact-social-links {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
      justify-content: center;
    }
    .contact-social-links a {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 12px 28px;
      border-radius: 60px;
      background: #F8FAFC;
      border: 1px solid #E5E7EB;
      text-decoration: none;
      color: #0F172A;
      font-weight: 500;
      transition: all 0.3s;
    }
    .contact-social-links a:hover {
      background: #fff;
      box-shadow: 0 8px 24px rgba(0,0,0,0.06);
      transform: translateY(-2px);
      border-color: #2563EB30;
    }
    .contact-social-links a i { font-size: 1.4rem; }
    .contact-social-links a.whatsapp i { color: #25D366; }
    .contact-social-links a.instagram i { color: #E4405F; }
    .contact-social-links a.telegram i { color: #0088CC; }
  </style>
</head>
<body>

<!-- ====== ANNOUNCEMENT BAR ====== -->
<div class="announcement-bar">
  <div class="scroll-text">
    🔥 PREMIUM BUNDLE PACK | 2 Complete Ethical Hacking Courses | Worth ₹15,000+ | Today Only ₹199 | Save 98% | One-Time Purchase • Instant Download 🔥
  </div>
</div>

<!-- ====== NAVBAR ====== -->
<nav class="navbar navbar-expand-lg sticky-top py-2">
  <div class="container">
    <a class="navbar-brand" href="#"><i class="bi bi-shield-fill-check"></i> HIFI11 ACADEMY</a>
    <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center gap-2">
        <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#courses">Bundle</a></li>
        <li class="nav-item"><a class="nav-link" href="#features">Features</a></li>
        <li class="nav-item"><a class="nav-link" href="#founder">Founder</a></li>
        <li class="nav-item"><a class="nav-link" href="#testimonials">Testimonials</a></li>
        <li class="nav-item"><a class="nav-link" href="#faq">FAQ</a></li>
        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
        <li class="nav-item ms-lg-2"><a href="#launch" class="btn btn-primary rounded-pill px-4 py-2 gradient-btn">Download Bundle</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- ====== HERO ====== -->
<section id="home" class="premium-bg py-5 overflow-hidden" style="position:relative;">
  <div class="glow-sphere" style="width:400px;height:400px;background:#2563EB;top:-10%;left:-5%;"></div>
  <div class="glow-sphere" style="width:300px;height:300px;background:#06B6D4;bottom:-5%;right:-5%;"></div>
  <div class="grid-overlay"></div>
  <div class="container py-4 position-relative" style="z-index:1;">
    <div class="row align-items-center g-5">
      <div class="col-lg-6" data-aos="fade-right">
        <span class="badge-hero mb-3 d-inline-flex align-items-center gap-2 bg-white px-4 py-2 rounded-pill border">
          <i class="bi bi-rocket-takeoff text-primary"></i> 🚀 PREMIUM BUNDLE PACK — 2 COMPLETE COURSES
        </span>
        <h1 class="display-3 fw-bold text-dark lh-1 mb-3">ETHICAL HACKING <br>BUNDLE PACK</h1>
        <p class="fw-bold text-primary fs-4">தமிழிலேயே... 2 Premium Courses • Instant Download</p>
        <p class="lead text-secondary mb-3">After payment, you'll receive the complete downloadable bundle immediately. No online platform. No monthly subscription. Own the files forever. Watch offline on any device.</p>
        <div class="d-flex flex-wrap gap-2 mb-3">
          <span class="trust-badge"><i class="bi bi-check-circle-fill"></i> 2 Complete Courses</span>
          <span class="trust-badge"><i class="bi bi-check-circle-fill"></i> Instant Download After Payment</span>
          <span class="trust-badge"><i class="bi bi-check-circle-fill"></i> One-Time Purchase</span>
          <span class="trust-badge"><i class="bi bi-check-circle-fill"></i> Offline Viewing</span>
        </div>
        
        <!-- PRICING CARD -->
        <div class="pricing-card mb-4">
          <div class="d-flex justify-content-between align-items-center">
            <span class="text-muted">Estimated Value</span>
            <span class="strike">₹15,000+</span>
          </div>
          <div class="d-flex align-items-end gap-3">
            <span class="price">₹199</span>
            <span class="badge-save">🔥 SAVE ₹14,801 • 98% OFF</span>
          </div>
          <div class="mt-1"><span class="badge bg-warning text-dark">⏳ Limited Launch Offer • One-Time Purchase</span></div>
        </div>

        <div class="d-flex flex-wrap gap-3">
          <a href="#launch" class="btn btn-primary btn-lg rounded-pill px-5 py-3 shadow-lg gradient-btn">Download Bundle <i class="bi bi-arrow-right ms-2"></i></a>
        </div>
        
        <!-- Trust badges under CTA -->
        <div class="d-flex flex-wrap gap-2 mt-3">
          <span class="trust-badge"><i class="bi bi-check-circle-fill"></i> Instant Download</span>
          <span class="trust-badge"><i class="bi bi-check-circle-fill"></i> Own Forever</span>
          <span class="trust-badge"><i class="bi bi-check-circle-fill"></i> 2 Premium Courses</span>
          <span class="trust-badge"><i class="bi bi-check-circle-fill"></i> Offline Access</span>
          <span class="trust-badge"><i class="bi bi-check-circle-fill"></i> No Subscription</span>
          <span class="trust-badge"><i class="bi bi-check-circle-fill"></i> Future Updates</span>
        </div>
      </div>
      <div class="col-lg-6" data-aos="fade-left">
        <div class="hero-image-container float-slow">
          <img src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&h=500&fit=crop&crop=center&q=80" alt="Ethical Hacker" class="img-fluid" loading="lazy" />
          <div class="cyber-float" style="top:8%; left:6%;"><i class="bi bi-shield-check text-primary"></i> Security Shield</div>
          <div class="cyber-float" style="bottom:12%; right:8%;"><i class="bi bi-phone text-primary"></i> Android Cyber UI</div>
          <div class="cyber-float" style="top:20%; right:6%;"><i class="bi bi-code-slash text-primary"></i> Kali Terminal</div>
          <div class="cyber-float" style="bottom:30%; left:8%;"><i class="bi bi-graph-up-arrow text-success"></i> Cyber Dashboard</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- WAVE -->
<svg class="wave-divider" viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,60 720,0 1080,30 C1260,45 1380,30 1440,20 L1440,60 L0,60 Z" /></svg>

<!-- ====== STATISTICS ====== -->
<section class="stats-section py-5 bg-soft-primary">
  <div class="container">
    <div class="row text-center g-4">
      <div class="col-6 col-md-4 col-lg-2" data-aos="zoom-in">
        <span class="counter h2 fw-bold text-primary" data-target="29">0</span><span class="h2 fw-bold text-primary">+</span>
        <p class="text-muted small">Practical Modules</p>
      </div>
      <div class="col-6 col-md-4 col-lg-2" data-aos="zoom-in" data-aos-delay="100">
        <span class="counter h2 fw-bold text-primary" data-target="103">0</span><span class="h2 fw-bold text-primary">+</span>
        <p class="text-muted small">HD Video Lessons</p>
      </div>
      <div class="col-6 col-md-4 col-lg-2" data-aos="zoom-in" data-aos-delay="200">
        <span class="counter h2 fw-bold text-primary" data-target="10">0</span><span class="h2 fw-bold text-primary">+</span>
        <p class="text-muted small">Hours of Content</p>
      </div>
      <div class="col-6 col-md-4 col-lg-2" data-aos="zoom-in" data-aos-delay="300">
        <i class="bi bi-infinity h2 text-primary"></i>
        <p class="text-muted small">Lifetime Ownership</p>
      </div>
      <div class="col-6 col-md-4 col-lg-2" data-aos="zoom-in" data-aos-delay="400">
        <i class="bi bi-download h2 text-primary"></i>
        <p class="text-muted small">Instant Download</p>
      </div>
      <div class="col-6 col-md-4 col-lg-2" data-aos="zoom-in" data-aos-delay="500">
        <i class="bi bi-translate h2 text-primary"></i>
        <p class="text-muted small">Tamil Language</p>
      </div>
    </div>
  </div>
</section>

<!-- WAVE -->
<svg class="wave-divider wave-divider-dark" viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,0 720,60 1080,30 C1260,15 1380,30 1440,40 L1440,0 L0,0 Z" /></svg>

<!-- ====== VALUE COMPARISON TABLE ====== -->
<section class="py-5 premium-bg">
  <div class="container">
    <h2 class="display-5 fw-bold text-center mb-3" data-aos="fade-up">Why This Bundle is Worth ₹15,000+</h2>
    <p class="text-center text-secondary mb-5" data-aos="fade-up">Compare the value — and see why you're saving ₹14,801 today</p>
    <div class="row justify-content-center" data-aos="fade-up">
      <div class="col-lg-8">
        <div class="value-table">
          <div class="row-item"><span>Ethical Hacking Master in Tamil</span><span class="fw-bold">₹7,999</span></div>
          <div class="row-item"><span>Android Hacking Masterclass</span><span class="fw-bold">₹4,999</span></div>
          <div class="row-item"><span>Premium PDF Notes</span><span class="fw-bold">₹999</span></div>
          <div class="row-item"><span>Practice Files</span><span class="fw-bold">₹799</span></div>
          <div class="row-item"><span>Tools Collection</span><span class="fw-bold">₹499</span></div>
          <div class="row-item"><span>Certificate</span><span class="fw-bold">₹499</span></div>
          <div class="row-item"><span>Future Updates</span><span class="fw-bold">₹699</span></div>
          <div class="row-item total"><span>Total Value</span><span>₹15,000+</span></div>
          <div class="row-item highlight"><span>Today's Launch Price</span><span class="fw-bold text-primary">₹199</span></div>
          <div class="row-item" style="background:#F0FDF4;border-top:2px solid #10B981;"><span class="fw-bold text-success">🎯 Save ₹14,801</span><span class="badge-save">98% OFF</span></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- WAVE -->
<svg class="wave-divider" viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,60 720,0 1080,30 C1260,45 1380,30 1440,20 L1440,60 L0,60 Z" /></svg>

<!-- ====== COURSE BUNDLE ====== -->
<section id="courses" class="course-section py-5 bg-soft-primary">
  <div class="container">
    <div class="text-center mb-5" data-aos="fade-up">
      <h2 class="display-5 fw-bold">Complete Premium Bundle Pack</h2>
      <p class="lead text-secondary">This is a complete downloadable bundle. Contains 2 premium hacking courses. Download starts immediately after payment. Files belong to you forever. Offline viewing supported on any device.</p>
    </div>
    <div class="row g-5 align-items-center">
      <div class="col-lg-6" data-aos="flip-left">
        <div class="bundle-box float-slow p-4" style="background:linear-gradient(145deg,#FFFFFF,#F1F5F9);border-radius:40px;padding:2rem 1.5rem;box-shadow:0 20px 60px -10px rgba(37,99,235,0.08),0 0 0 1px rgba(229,231,235,0.3);transition:all 0.4s;transform:perspective(1200px) rotateY(-2deg) rotateX(2deg);">
          <div class="d-flex justify-content-between align-items-start">
            <span class="badge-launch" style="background:linear-gradient(135deg,#2563EB,#06B6D4);color:#fff;padding:6px 18px;border-radius:40px;font-size:0.75rem;font-weight:600;">🚀 LAUNCH BUNDLE</span>
            <div><span class="text-muted text-decoration-line-through fs-5 me-2">₹999</span><span class="fw-bold text-primary display-5">₹199</span></div>
          </div>
          <h3 class="fw-bold mt-3">ETHICAL HACKING <br>BUNDLE PACK</h3>
          <p class="text-muted small">2 Premium Courses • Instant Download • One-Time Purchase</p>
          <div class="d-flex flex-wrap gap-2 my-3">
            <span class="badge bg-light text-dark border px-3 py-2">2 Courses Included</span>
            <span class="badge bg-light text-dark border px-3 py-2">103+ Video Lessons</span>
            <span class="badge bg-light text-dark border px-3 py-2">Downloadable Files</span>
            <span class="badge bg-light text-dark border px-3 py-2">Future Updates</span>
            <span class="badge bg-light text-dark border px-3 py-2">Certificate</span>
            <span class="badge bg-light text-dark border px-3 py-2">Offline Access</span>
          </div>
          <a href="#launch" class="btn btn-primary rounded-pill px-4 py-2 gradient-btn w-100">Buy Bundle Pack <i class="bi bi-arrow-right ms-2"></i></a>
          <p class="text-muted small mt-2 text-center">⏳ Limited Launch Offer • Instant Download After Payment</p>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="row g-3">
          <div class="col-6" data-aos="fade-up" data-aos-delay="100">
            <div class="device-mockup" style="background:#F8FAFC;border-radius:28px;padding:1.2rem;border:1px solid #E5E7EB;transition:all 0.3s;box-shadow:0 8px 24px rgba(0,0,0,0.02);">
              <img src="https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=400&h=300&fit=crop&crop=center&q=80" alt="Course 1" loading="lazy" class="img-fluid" style="border-radius:16px;width:100%;" />
              <h6 class="mt-2 text-center fw-bold">Course 1</h6>
              <p class="small text-muted text-center">Ethical Hacking Master in Tamil</p>
              <div class="d-flex flex-wrap gap-1 justify-content-center">
                <span class="badge bg-light text-dark border">Linux</span><span class="badge bg-light text-dark border">Networking</span>
                <span class="badge bg-light text-dark border">Nmap</span><span class="badge bg-light text-dark border">Web Hacking</span>
                <span class="badge bg-light text-dark border">CTF</span><span class="badge bg-light text-dark border">Android</span>
              </div>
            </div>
          </div>
          <div class="col-6" data-aos="fade-up" data-aos-delay="200">
            <div class="device-mockup" style="background:#F8FAFC;border-radius:28px;padding:1.2rem;border:1px solid #E5E7EB;transition:all 0.3s;box-shadow:0 8px 24px rgba(0,0,0,0.02);">
              <img src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=300&fit=crop&crop=center&q=80" alt="Course 2" loading="lazy" class="img-fluid" style="border-radius:16px;width:100%;" />
              <h6 class="mt-2 text-center fw-bold">Course 2</h6>
              <p class="small text-muted text-center">Android Hacking Masterclass</p>
              <div class="d-flex flex-wrap gap-1 justify-content-center">
                <span class="badge bg-light text-dark border">Metasploit</span><span class="badge bg-light text-dark border">Payload</span>
                <span class="badge bg-light text-dark border">ADB</span><span class="badge bg-light text-dark border">APK</span>
                <span class="badge bg-light text-dark border">Port Forward</span><span class="badge bg-light text-dark border">Automation</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- WAVE -->
<svg class="wave-divider wave-divider-dark" viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,0 720,60 1080,30 C1260,15 1380,30 1440,40 L1440,0 L0,0 Z" /></svg>

<!-- ====== BONUS SECTION ====== -->
<section class="py-5 premium-bg">
  <div class="container">
    <h2 class="display-5 fw-bold text-center mb-3" data-aos="fade-up">🎁 What's Included in the Bundle</h2>
    <p class="text-center text-secondary mb-5" data-aos="fade-up">Everything you need — all downloadable files, yours forever</p>
    <div class="row g-4" data-aos="fade-up">
      <div class="col-6 col-md-4 col-lg-3"><div class="bonus-card"><i class="bi bi-file-pdf"></i><h6 class="mt-2">Premium PDF Notes</h6></div></div>
      <div class="col-6 col-md-4 col-lg-3"><div class="bonus-card"><i class="bi bi-folder"></i><h6 class="mt-2">Practice Files</h6></div></div>
      <div class="col-6 col-md-4 col-lg-3"><div class="bonus-card"><i class="bi bi-tools"></i><h6 class="mt-2">Tools Collection</h6></div></div>
      <div class="col-6 col-md-4 col-lg-3"><div class="bonus-card"><i class="bi bi-arrow-repeat"></i><h6 class="mt-2">Future Updates</h6></div></div>
      <div class="col-6 col-md-4 col-lg-3"><div class="bonus-card"><i class="bi bi-award"></i><h6 class="mt-2">Certificate</h6></div></div>
      <div class="col-6 col-md-4 col-lg-3"><div class="bonus-card"><i class="bi bi-people"></i><h6 class="mt-2">Private Community</h6></div></div>
    </div>
  </div>
</section>

<!-- WAVE -->
<svg class="wave-divider" viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,60 720,0 1080,30 C1260,45 1380,30 1440,20 L1440,60 L0,60 Z" /></svg>

<!-- ====== WHY HIFI11 ====== -->
<section id="features" class="why-section py-5 bg-soft-primary">
  <div class="container">
    <div class="text-center mb-5" data-aos="fade-up">
      <h2 class="display-5 fw-bold">Why Thousands Choose HIFI11 Bundle Pack</h2>
    </div>
    <div class="row g-4">
      <div class="col-6 col-md-4 col-lg-3" data-aos="flip-up"><div class="icon-feature"><i class="bi bi-box"></i><h6 class="mt-2">Premium Bundle Pack</h6><p class="text-muted small">2 Complete Courses</p></div></div>
      <div class="col-6 col-md-4 col-lg-3" data-aos="flip-up" data-aos-delay="50"><div class="icon-feature"><i class="bi bi-download"></i><h6 class="mt-2">Instant Download</h6><p class="text-muted small">After Payment</p></div></div>
      <div class="col-6 col-md-4 col-lg-3" data-aos="flip-up" data-aos-delay="100"><div class="icon-feature"><i class="bi bi-device-ssd"></i><h6 class="mt-2">Offline Viewing</h6><p class="text-muted small">On Any Device</p></div></div>
      <div class="col-6 col-md-4 col-lg-3" data-aos="flip-up" data-aos-delay="150"><div class="icon-feature"><i class="bi bi-infinity"></i><h6 class="mt-2">Own Forever</h6><p class="text-muted small">No Subscription</p></div></div>
    </div>
  </div>
</section>

<!-- WAVE -->
<svg class="wave-divider wave-divider-dark" viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,0 720,60 1080,30 C1260,15 1380,30 1440,40 L1440,0 L0,0 Z" /></svg>

<!-- ====== FOUNDER ====== -->
<section id="founder" class="py-5 premium-bg">
  <div class="container">
    <div class="row align-items-center g-5">
      <div class="col-md-5" data-aos="fade-right">
        <div class="bg-white p-4 rounded-4 shadow-sm text-center">
          <div class="rounded-circle mx-auto mb-3" style="width:160px;height:160px;overflow:hidden;border:3px solid #E5E7EB;">
            <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&h=200&fit=crop&crop=face&q=80" alt="Surya Prakash" class="w-100 h-100 object-fit-cover" />
          </div>
          <h3 class="fw-bold">SURYA PRAKASH E</h3>
          <p class="text-muted">Founder &amp; CEO — HIFI11 Technologies</p>
          <p class="text-secondary">எல்லோருக்கும் தரமான Cyber Security Education கிடைக்க வேண்டும் என்பதற்காக HIFI11 Academy உருவாக்கப்பட்டது. ₹15,000+ மதிப்புள்ள Premium Bundle Pack-ஐ Launch Offer-ஆக வெறும் ₹199-க்கு வழங்குகிறோம். இது ஒரு Limited Time Launch Offer. Instant Download.</p>
          <div class="d-flex flex-wrap gap-2 justify-content-center">
            <span class="badge bg-primary text-white p-2">Founder</span>
            <span class="badge bg-secondary text-white p-2">CEO</span>
            <span class="badge bg-success text-white p-2">Cyber Security Trainer</span>
            <span class="badge bg-warning text-dark p-2">Entrepreneur</span>
          </div>
        </div>
      </div>
      <div class="col-md-7" data-aos="fade-left">
        <h2 class="display-5 fw-bold">About the founder</h2>
        <p class="lead text-secondary">Making Premium Cyber Security Education Affordable for Everyone.</p>
        <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&h=400&fit=crop&crop=center&q=80" alt="Team" class="img-fluid rounded-4 shadow-sm float-slow" loading="lazy" />
      </div>
    </div>
  </div>
</section>

<!-- WAVE -->
<svg class="wave-divider" viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,60 720,0 1080,30 C1260,45 1380,30 1440,20 L1440,60 L0,60 Z" /></svg>

<!-- ====== TESTIMONIALS ====== -->
<section id="testimonials" class="py-5 bg-soft-primary">
  <div class="container">
    <h2 class="display-5 fw-bold text-center mb-5" data-aos="fade-up">What Our Customers Say</h2>
    <div class="row g-4">
      <div class="col-md-3" data-aos="fade-up">
        <div class="glass-card p-4 text-center">
          <div class="mb-2"><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i></div>
          <p class="text-secondary">"₹199க்கு இவ்வளவு Premium Quality Bundle கிடைக்கும் என்று எதிர்பார்க்கவில்லை."</p>
          <div class="d-flex align-items-center justify-content-center gap-2"><img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face&q=80" class="rounded-circle" width="40" height="40" alt="" /><div><h6 class="mb-0">Karthik R.</h6><span class="text-muted small">Customer</span></div></div>
        </div>
      </div>
      <div class="col-md-3" data-aos="fade-up" data-aos-delay="100">
        <div class="glass-card p-4 text-center">
          <div class="mb-2"><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i></div>
          <p class="text-secondary">"தமிழில் Ethical Hacking கற்றுக்கொள்ள இதைவிட சிறந்த Bundle இல்லை."</p>
          <div class="d-flex align-items-center justify-content-center gap-2"><img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=40&h=40&fit=crop&crop=face&q=80" class="rounded-circle" width="40" height="40" alt="" /><div><h6 class="mb-0">Divya S.</h6><span class="text-muted small">Developer</span></div></div>
        </div>
      </div>
      <div class="col-md-3" data-aos="fade-up" data-aos-delay="200">
        <div class="glass-card p-4 text-center">
          <div class="mb-2"><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i></div>
          <p class="text-secondary">"Linux முதல் Android Hacking வரை அனைத்தும் Practical. Download உடனே கிடைச்சது."</p>
          <div class="d-flex align-items-center justify-content-center gap-2"><img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face&q=80" class="rounded-circle" width="40" height="40" alt="" /><div><h6 class="mb-0">Arun M.</h6><span class="text-muted small">Freelancer</span></div></div>
        </div>
      </div>
      <div class="col-md-3" data-aos="fade-up" data-aos-delay="300">
        <div class="glass-card p-4 text-center">
          <div class="mb-2"><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i><i class="bi bi-star-fill text-warning"></i></div>
          <p class="text-secondary">"College Students கண்டிப்பாக வாங்க வேண்டிய Bundle Pack."</p>
          <div class="d-flex align-items-center justify-content-center gap-2"><img src="https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=40&h=40&fit=crop&crop=face&q=80" class="rounded-circle" width="40" height="40" alt="" /><div><h6 class="mb-0">Priya V.</h6><span class="text-muted small">Beginner</span></div></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- WAVE -->
<svg class="wave-divider wave-divider-dark" viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,0 720,60 1080,30 C1260,15 1380,30 1440,40 L1440,0 L0,0 Z" /></svg>

<!-- ====== FAQ ====== -->
<section id="faq" class="py-5 premium-bg">
  <div class="container">
    <h2 class="display-5 fw-bold text-center mb-5" data-aos="fade-up">Frequently Asked Questions</h2>
    <div class="accordion accordion-flush" id="faqAccordion" data-aos="fade-up">
      <div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q1">Is this a downloadable bundle?</button></h2><div id="q1" class="accordion-collapse collapse" data-bs-parent="#faqAccordion"><div class="accordion-body">Yes! This is a premium digital bundle pack. After payment, you'll receive instant download links for all files.</div></div></div>
      <div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q2">Is this an online course platform?</button></h2><div id="q2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion"><div class="accordion-body">No. This is NOT an online learning platform. No monthly subscription. You get downloadable files that you own forever.</div></div></div>
      <div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q3">Can I watch offline?</button></h2><div id="q3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion"><div class="accordion-body">Absolutely! All files are downloadable. Watch offline on your mobile, tablet, or PC anytime.</div></div></div>
      <div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q4">Is this suitable for beginners?</button></h2><div id="q4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion"><div class="accordion-body">Yes. The bundle starts from basics and goes step-by-step. No prior experience needed.</div></div></div>
      <div class="accordion-item"><h2 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#q5">Will I get future updates?</button></h2><div id="q5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion"><div class="accordion-body">Yes, future bundle updates are included at no extra cost.</div></div></div>
    </div>
  </div>
</section>

<!-- WAVE -->
<svg class="wave-divider" viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,60 720,0 1080,30 C1260,45 1380,30 1440,20 L1440,60 L0,60 Z" /></svg>

<!-- ====== CONTACT SECTION ====== -->
<section id="contact" class="py-5 bg-soft-primary">
  <div class="container">
    <h2 class="display-5 fw-bold text-center mb-4" data-aos="fade-up">Connect With Us</h2>
    <p class="text-center text-secondary mb-5" data-aos="fade-up">Reach out anytime — we're here to help!</p>
    <div class="contact-social-links" data-aos="fade-up">
      <a href="tel:+919380386500" class="whatsapp"><i class="bi bi-whatsapp"></i> +91 9380386500</a>
      <a href="https://instagram.com/_devil_heart_hacker" target="_blank" class="instagram"><i class="bi bi-instagram"></i> @_devil_heart_hacker</a>
      <a href="https://t.me/devil_heart_hack" target="_blank" class="telegram"><i class="bi bi-telegram"></i> @devil_heart_hack</a>
    </div>
  </div>
</section>

<!-- WAVE -->
<svg class="wave-divider wave-divider-dark" viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,0 720,60 1080,30 C1260,15 1380,30 1440,40 L1440,0 L0,0 Z" /></svg>

<!-- ====== FINAL CTA ====== -->
<section id="launch" class="py-5 bg-soft-primary">
  <div class="container">
    <div class="cta-apple text-white text-center" data-aos="flip-up">
      <div class="glow-ring"></div>
      <span class="badge bg-white text-primary px-4 py-2 rounded-pill mb-3">🔥 Limited Launch Offer • One-Time Purchase</span>
      <h2 class="display-3 fw-bold">Download Your Bundle Today</h2>
      <p class="lead opacity-75">இன்று Download செய்து உங்கள் Cyber Security Career-ஐ ஆரம்பியுங்கள். Instant Download After Payment.</p>
      
      <div class="d-flex justify-content-center align-items-center gap-4 my-4 flex-wrap">
        <div><span class="text-white-50 text-decoration-line-through fs-3">₹15,000+</span><br><span class="text-white-50 small">Estimated Value</span></div>
        <div><span class="fw-bold display-1">₹199</span><br><span class="small opacity-75">Today Only</span></div>
        <div><span class="badge-save" style="font-size:1.2rem;padding:8px 24px;">SAVE ₹14,801 • 98% OFF</span></div>
      </div>
      
      <a href="checkout.php" class="btn btn-apple ripple">🚀 GET DOWNLOAD NOW</a>
      <p class="mt-3 opacity-75 small">⚡ Instant Download • One-Time Payment • Own Forever • No Subscription</p>
      
      <!-- Countdown -->
      <div class="countdown mt-3" id="countdown">
        <div class="unit"><div class="num" id="hours">12</div><div class="label">Hours</div></div>
        <div class="unit"><div class="num" id="minutes">45</div><div class="label">Minutes</div></div>
        <div class="unit"><div class="num" id="seconds">30</div><div class="label">Seconds</div></div>
      </div>
    </div>
  </div>
</section>

<!-- WAVE -->
<svg class="wave-divider wave-divider-dark" viewBox="0 0 1440 60" preserveAspectRatio="none"><path d="M0,30 C360,0 720,60 1080,30 C1260,15 1380,30 1440,40 L1440,0 L0,0 Z" /></svg>

<!-- ====== FOOTER ====== -->
<footer class="footer py-5" style="background:#0F172A;color:#94A3B8;">
  <div class="container">
    <div class="row g-4">
      <div class="col-md-4">
        <h5 class="text-white fw-bold"><i class="bi bi-shield-fill-check text-primary"></i> HIFI11 ACADEMY</h5>
        <p class="small">🔥 HIFI11 Launch Batch 2026<br>Premium Digital Bundle Pack — Instant Download, Own Forever.</p>
        <p class="small"><i class="bi bi-phone me-2"></i> +91 9380386500</p>
        <p class="small"><i class="bi bi-instagram me-2"></i> <a href="https://instagram.com/_devil_heart_hacker" target="_blank" class="text-light text-decoration-none">@_devil_heart_hacker</a></p>
        <p class="small"><i class="bi bi-telegram me-2"></i> <a href="https://t.me/devil_heart_hack" target="_blank" class="text-light text-decoration-none">@devil_heart_hack</a></p>
      </div>
      <div class="col-md-2">
        <h6 class="text-white">Quick Links</h6>
        <ul class="list-unstyled small">
          <li><a href="#home" class="text-light text-decoration-none">Home</a></li>
          <li><a href="#courses" class="text-light text-decoration-none">Bundle</a></li>
          <li><a href="#features" class="text-light text-decoration-none">Features</a></li>
          <li><a href="#founder" class="text-light text-decoration-none">Founder</a></li>
        </ul>
      </div>
      <div class="col-md-2">
        <h6 class="text-white">About</h6>
        <ul class="list-unstyled small">
          <li><a href="#testimonials" class="text-light text-decoration-none">Testimonials</a></li>
          <li><a href="#faq" class="text-light text-decoration-none">FAQ</a></li>
          <li><a href="#contact" class="text-light text-decoration-none">Contact</a></li>
        </ul>
      </div>
      <div class="col-md-4 text-md-end">
        <h6 class="text-white">Founder</h6>
        <p class="small mb-0">SURYA PRAKASH E</p>
        <p class="small text-muted">CEO, HIFI11 Technologies</p>
        <p class="small mt-3 mb-0">&copy; 2026 HIFI11 Academy. All Rights Reserved.</p>
        <p class="small text-muted">Made with care in Tamil Nadu, India.</p>
      </div>
    </div>
  </div>
</footer>

<!-- ====== FLOATING SOCIAL BUTTONS ====== -->
<a href="https://wa.me/919380386500" target="_blank" class="social-float whatsapp" aria-label="WhatsApp">
  <i class="bi bi-whatsapp"></i>
  <span class="tooltip-text">WhatsApp</span>
</a>
<a href="https://instagram.com/_devil_heart_hacker" target="_blank" class="social-float instagram" aria-label="Instagram">
  <i class="bi bi-instagram"></i>
  <span class="tooltip-text">Instagram</span>
</a>
<a href="https://t.me/devil_heart_hack" target="_blank" class="social-float telegram" aria-label="Telegram">
  <i class="bi bi-telegram"></i>
  <span class="tooltip-text">Telegram</span>
</a>
<a href="#" class="social-float top" id="scrollTop" aria-label="Scroll to top">
  <i class="bi bi-chevron-up"></i>
  <span class="tooltip-text">Back to top</span>
</a>

<!-- ====== STICKY MOBILE BUY ====== -->
<div class="sticky-mobile-buy">
  <div><span class="price">₹199</span> <span class="text-muted small text-decoration-line-through">₹15,000+</span></div>
  <a href="#launch" class="btn btn-primary gradient-btn">Download Bundle</a>
</div>

<!-- ====== LIVE DOWNLOAD NOTIFICATIONS ====== -->
<div class="download-notification" id="downloadNotif">
  <div class="d-flex align-items-start gap-3">
    <div class="avatar" id="notifAvatar">AK</div>
    <div class="notif-text flex-grow-1">
      <div><span class="online-dot"></span> <strong id="notifName">Aravind</strong></div>
      <div class="action" id="notifAction">just downloaded the bundle 🎉</div>
      <div class="time">Just now</div>
    </div>
  </div>
</div>

<!-- ====== SCRIPTS ====== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  (function() {
    AOS.init({ once: false, duration: 800 });

    // ====== STATISTICS COUNTERS ======
    const counters = document.querySelectorAll('.counter');
    const speed = 70;
    const animateCounter = (el) => {
      const target = parseInt(el.getAttribute('data-target'));
      let current = 0;
      const inc = Math.ceil(target / 35);
      const timer = setInterval(() => {
        current += inc;
        if (current >= target) { el.textContent = target; clearInterval(timer); } 
        else el.textContent = current;
      }, speed);
    };
    const counterObserver = new IntersectionObserver((entries) => {
      entries.forEach(e => { if(e.isIntersecting) { animateCounter(e.target); counterObserver.unobserve(e.target); } });
    }, { threshold: 0.4 });
    counters.forEach(c => counterObserver.observe(c));

    // ====== LIVE DOWNLOAD NOTIFICATIONS ======
    const notif = document.getElementById('downloadNotif');
    const notifName = document.getElementById('notifName');
    const notifAction = document.getElementById('notifAction');
    const notifAvatar = document.getElementById('notifAvatar');

    const usernames = [
      'Aravind', 'Karthik', 'Priya', 'Vignesh', 'Sanjay', 'Harini', 'Dinesh', 'Ajith',
      'Gokul', 'Deepika', 'Suresh', 'Anjali', 'Vijay', 'Meena', 'Rahul', 'Kavya',
      'Arun', 'Swathi', 'Prakash', 'Nandhini', 'Murali', 'Divya', 'Sathish', 'Lakshmi',
      'Ganesh', 'Bharath', 'Sneha', 'Ravi', 'Pavithra', 'Kumar', 'Anitha', 'Selvam',
      'Jothi', 'Mani', 'Vasanthi', 'Murugan', 'Malar', 'Saravanan', 'Ezhil', 'Kayal',
      'Tharun', 'Nisha', 'Kishore', 'Janani', 'Vinoth', 'Saranya', 'Prabhu', 'Indhu',
      'Mohan', 'Rekha', 'Gowtham', 'Sowmiya', 'Devi', 'Ranjith', 'Keerthi', 'Dhanush',
      'Abirami', 'Bala', 'Chitra', 'Eswar', 'Gayathri', 'Hari', 'Ishwarya', 'Jagan'
    ];

    const actions = [
      'just downloaded the bundle 🎉',
      'purchased the bundle pack 🔥',
      'got instant download 🚀',
      'downloaded successfully ✅',
      'bought the launch bundle ⚡',
      'got the premium bundle ✨',
      'is now a HIFI11 customer 🛡️',
      'downloaded both courses 📚'
    ];

    let usedIndices = [];
    let currentTimeout = null;

    function getRandomUser() {
      if (usedIndices.length >= usernames.length) usedIndices = [];
      let idx;
      do {
        idx = Math.floor(Math.random() * usernames.length);
      } while (usedIndices.includes(idx));
      usedIndices.push(idx);
      return usernames[idx];
    }

    function getRandomAction() {
      return actions[Math.floor(Math.random() * actions.length)];
    }

    function getInitials(name) {
      return name.substring(0, 2).toUpperCase();
    }

    function showNotification() {
      const name = getRandomUser();
      const action = getRandomAction();
      
      notifName.textContent = name;
      notifAction.textContent = action;
      notifAvatar.textContent = getInitials(name);

      notif.classList.remove('hide');
      notif.classList.add('show');

      if (currentTimeout) clearTimeout(currentTimeout);
      currentTimeout = setTimeout(() => {
        notif.classList.remove('show');
        notif.classList.add('hide');
        const delay = 4000 + Math.random() * 4000;
        setTimeout(() => {
          showNotification();
        }, delay);
      }, 3500);
    }

    setTimeout(() => {
      showNotification();
    }, 3000);

    // Scroll to top
    document.getElementById('scrollTop').addEventListener('click', function(e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // Smooth scroll
    document.querySelectorAll('a[href^="#"]').forEach(a => {
      a.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href === "#") return;
        const target = document.querySelector(href);
        if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
      });
    });

    // Countdown timer
    let totalSeconds = 12 * 3600 + 45 * 60 + 30;
    const hoursEl = document.getElementById('hours');
    const minutesEl = document.getElementById('minutes');
    const secondsEl = document.getElementById('seconds');
    setInterval(() => {
      if (totalSeconds <= 0) return;
      totalSeconds--;
      const h = Math.floor(totalSeconds / 3600);
      const m = Math.floor((totalSeconds % 3600) / 60);
      const s = totalSeconds % 60;
      hoursEl.textContent = String(h).padStart(2, '0');
      minutesEl.textContent = String(m).padStart(2, '0');
      secondsEl.textContent = String(s).padStart(2, '0');
    }, 1000);

  })();
</script>
</body>
</html>